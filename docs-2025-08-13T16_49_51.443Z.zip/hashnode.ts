export default {
    linkedProjectId: "",
    previewProjectId: "",
};