---
title: Root Application File (root.tsx) – Function Documentation
label: Root
slug: root
description: >-
  This file defines the root layout, authentication context, and error
  boundaries for the Remix web application.
visibility: PUBLIC
---
## **Exports**

### 1. `links`

A Remix `LinksFunction` that returns an array of `<link>` tags for preconnecting to Google Fonts, loading the Inter font, and setting up various icons and the web manifest.

***

### 2. `Layout`

**Props:**

* `children: React.ReactNode` – The main content of the app.

**Description:**\
Defines the overall HTML structure and theming for the app.

* Sets up meta tags, theme color, and font links.

* Wraps the app in a `ThemeProvider` for consistent theming.

* Includes a mobile warning, main content area, and footer.

* Adds Remix's `ScrollRestoration` and `Scripts` for client-side navigation and hydration.

***

### 3. `AuthProvider`

**Props:**

* `children: React.ReactNode` – The content to be wrapped with authentication context.

**Description:**\
Provides authentication state to the app using React context.

* Listens for Firebase authentication state changes.

* Makes the current user and a setter available via `AuthContext`.

***

### 4. App (default export)

**Description:**\
The main entry point for the app.

* Wraps the routed content (`<Outlet />`) in the `AuthProvider` so all routes have access to authentication state.

***

### 5. `ErrorBoundary`

**Description:**\
Handles uncaught errors and route errors in the app.

* If the error is a route error, displays the status and message.

* Otherwise, shows a generic 500 error page.

* Both error views use the `ThemeProvider` and provide a link to return home.

***

## **Additional Notes**

* Imports global and module CSS for styling.

* Uses Remix's routing and error handling APIs.

* Integrates theming and authentication context at the root level for consistent access throughout the app.
