---
title: Notes Management Utilities (notes-manage.tsx)
label: Notes Management Utilities (notes-manage.tsx)
slug: notes-management-utilities-notes-managetsx
description: >-
  This file provides utility functions for saving and retrieving notes
  associated with specific images in a user's case. It interacts with a backend
  data worker for secure storage and retrieval.
visibility: PUBLIC
---
## **Types**

### `NotesData`

Represents the structure of a notes object, including:

* Case and item identifiers (`leftCase`, `rightCase`, `leftItem`, `rightItem`)

* Font color, class type, and optional custom class

* Class note, subclass flag, index type/number/color

* Support level, confirmation flag, additional notes

* `updatedAt`: Timestamp of last update

***

## **Constants**

* **DATA\_WORKER\_URL**: URL for the data worker API.

***

## **Functions**

### `saveNotes(user: User, caseNumber: string, imageId: string, notesData: NotesData): Promise<void>`

Saves notes for a specific image in a user's case:

* Adds/updates the `updatedAt` timestamp.

* Sends a PUT request to the data worker with the notes data.

* Throws an error if the request fails.

***

### `getNotes(user: User, caseNumber: string, imageId: string): Promise<NotesData | null>`

Retrieves notes for a specific image in a user's case:

* Sends a GET request to the data worker.

* Returns the notes data if found.

* Returns `null` if not found (404).

* Logs and returns `null` on other errors.

***

## **Notes**

* All API calls are authenticated using a data API key.

* Errors are logged and thrown or handled as appropriate for upstream handling.
