---
title: Case Management Utilities (case-manage.tsx)
label: Case Management Utilities (case-manage.tsx)
slug: case-management-utilities-case-managetsx
description: >-
  This file provides utility functions for managing user cases and their
  associated files in the Striae application. It interacts with backend workers
  for user and data storage, and includes validation and sorting logic.
visibility: PUBLIC
---
## **Types**

* **CaseData**: Represents a case, including creation date, case number, and associated files.

* **UserData**: Represents user data, including an array of cases and update timestamp.

* **FileData**: Represents a file, including ID, original filename, and upload date.

* **CasesToDelete**: Structure for specifying cases to delete.

***

## **Constants**

* **USER\_WORKER\_URL**: URL for the user worker API.

* **DATA\_WORKER\_URL**: URL for the data worker API.

* **CASE\_NUMBER\_REGEX**: Regex for validating case numbers.

* **MAX\_CASE\_NUMBER\_LENGTH**: Maximum allowed length for a case number.

***

## **Functions**

### `listCases(user: User): Promise<string[]>`

Fetches and returns a sorted list of case numbers for the given user from the backend KV store.

***

### `sortCaseNumbers(cases: string[]): string[]`

Sorts case numbers in ascending order, first by numbers, then by letters.

***

### `validateCaseNumber(caseNumber: string): boolean`

Validates a case number against the regex and length constraints.

***

### `checkExistingCase(user: User, caseNumber: string): Promise<CaseData | null>`

Checks if a case with the given number exists for the user in the data worker.

***

### `createNewCase(user: User, caseNumber: string): Promise<CaseData>`

Creates a new case for the user:

* Adds a new case file in the data worker.

* Updates the user's case list in the user worker.

***

### `renameCase(user: User, oldCaseNumber: string, newCaseNumber: string): Promise<void>`

Renames a case for the user:

* Validates case numbers.

* Checks for conflicts.

* Copies data to a new case number.

* Updates the user's case list.

* Deletes the old case from both user and data workers.

***

### `deleteCase(user: User, caseNumber: string): Promise<void>`

Deletes a case for the user:

* Deletes all associated files.

* Removes the case file from the data worker.

* Removes the case from the user's case list in the user worker.

***

## **Notes**

* All API calls are authenticated using API keys.

* File deletion is handled via the `deleteFile` utility.

* Errors are logged and thrown as needed for upstream handling.
