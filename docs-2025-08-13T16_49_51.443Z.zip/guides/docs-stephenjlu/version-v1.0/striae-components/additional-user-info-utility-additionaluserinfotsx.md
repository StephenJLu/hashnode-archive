---
title: Additional User Info Utility (additionalUserInfo.tsx)
label: Additional User Info Utility (additionalUserInfo.tsx)
slug: additional-user-info-utility-additionaluserinfotsx
description: >-
  This file provides a utility function to extract additional user information
  from a Firebase authentication result.
visibility: PUBLIC
---
## **Types**

### `AdditionalUserInfo`

An interface describing extra information about a user:

* `isNewUser`: `boolean` – Whether the user is new to the app.

* `profile`: `object | null` – The user's profile information (may include `name`, `given_name`, `family_name`, `email`, `picture`).

* `providerId`: `string | null` – The authentication provider's ID (e.g., "[google.com](http://google.com)").

***

## **Functions**

### `getAdditionalUserInfo(userCredential: UserCredential): AdditionalUserInfo`

Extracts additional user information from a Firebase `UserCredential` object.

* If `userCredential` is falsy, returns default values (`isNewUser: false`, `profile: null`, `providerId: null`).

* Otherwise, uses Firebase's `getAdditionalUserInfo` to extract:

  * `isNewUser`: Whether the user just registered.

  * `profile`: The user's profile object, if available.

  * `providerId`: The provider's ID.

**Returns:**\
An `AdditionalUserInfo` object with the extracted data.

***

This utility is used to determine if a user is new and to access their profile details after authentication, especially useful for social logins (e.g., Google).
