---
title: Image Management Utilities (image-manage.tsx)
label: Image Management Utilities (image-manage.tsx)
slug: image-management-utilities-image-managetsx
description: >-
  This file provides utility functions for managing image files associated with
  user cases in the Striae application. It handles file listing, uploading,
  deletion, and secure image URL generation, interacting with backend workers
  and Cloudflare Images.
visibility: PUBLIC
---
## **Types**

* **CaseData**: Represents a case, optionally including an array of files.

* **FileData**: Represents a file, including ID, original filename, and upload date.

* **ApiResponse**: Response structure for file listing.

* **ImageUploadResponse**: Response structure for image upload.

***

## **Constants**

* **WORKER\_URL**: URL for the data worker API.

* **IMAGE\_URL**: URL for the image worker API.

* **DEFAULT\_VARIANT**: Default image variant for delivery.

***

## **Functions**

### `fetchFiles(user: User, caseNumber: string): Promise<FileData[]>`

Fetches and returns the list of files for a given user and case from the data worker.

***

### `uploadFile(user: User, caseNumber: string, file: File, onProgress?: (progress: number) => void): Promise<FileData>`

Uploads an image file to the image worker:

* Tracks upload progress via the `onProgress` callback.

* On success, updates the case's file list in the data worker.

* Returns the new file's metadata.

***

### `deleteFile(user: User, caseNumber: string, fileId: string): Promise<void>`

Deletes an image file:

* Removes the image from the image worker.

* Attempts to delete any associated notes file (ignores 404 errors).

* Updates the case's file list in the data worker to remove the file.

***

### `getImageUrl(fileData: FileData): Promise<string>`

Generates a signed URL for secure image delivery:

* Fetches the account hash and image API key.

* Requests a signed URL from the image worker.

* Validates the returned URL for required signature and expiration parameters.

***

## **Internal Helpers**

* **getImageConfig()**: Fetches the account hash for image delivery.

***

## **Notes**

* All API calls are authenticated using API keys or tokens.

* File upload uses `XMLHttpRequest` for progress tracking.

* Errors are thrown for upstream handling and logged as needed.
