export default {
  settings: {
  "name": "v1.0",
  "slug": "v1.0",
  "isDefault": true
},
  sidebar: [
  [
    {
      "type": "page",
      "path": "/striae-overview/striae-overview",
      "visibility": "PUBLIC",
      "label": "Striae Overview"
    }
  ],
  [
    {
      "type": "page",
      "path": "/striae-pages/root",
      "visibility": "PUBLIC",
      "label": "Root"
    },
    {
      "type": "page",
      "path": "/striae-pages/login-approutesauthlogintsx",
      "pages": [
        {
          "type": "page",
          "path": "/striae-pages/login-approutesauthlogintsx/password-reset",
          "fullSlug": "/striae-pages/login-approutesauthlogintsx/password-reset",
          "filePath": "/striae-pages/login-approutesauthlogintsx/password-reset",
          "label": "Password Reset ",
          "slug": "password-reset",
          "content": "## **Main Component**\n\n### `PasswordReset`\n\nA React component that provides a password reset form for users who have forgotten their password. Integrates with Firebase Authentication to send password reset emails.\n\n#### Props:\n\n* `isModal?: boolean`\\\n  If true, renders the form as a modal overlay. If false or omitted, renders as a standalone page.\n\n* `onBack: () => void`\\\n  Callback function to return to the previous screen or close the modal.\n\n#### State:\n\n* `error`: Stores error or success messages for user feedback.\n\n* `isLoading`: Indicates if the reset email is being sent.\n\n#### Key Functions:\n\n* **handleReset**\\\n  Handles form submission. Sends a password reset email using Firebase. Displays a success message and automatically calls `onBack` after 2 seconds, or shows an error if sending fails.\n\n#### UI Structure:\n\n* If `isModal` is true, displays the form in a modal overlay.\n\n* Otherwise, displays the form as a full page with a logo link and styled container.\n\n#### Form Fields:\n\n* Email input (required)\n\n* Submit button (disabled while loading)\n\n* Back button (calls `onBack`)\n\n#### Error Handling:\n\n* Uses `handleAuthError` to translate Firebase errors into user-friendly messages.\n\n* Displays a success message when the reset email is sent.\n",
          "title": "Password Reset (passwordReset.tsx)",
          "visibility": "PUBLIC",
          "format": "MDX",
          "pages": [],
          "numberOfMatterLines": 0
        }
      ],
      "visibility": "PUBLIC",
      "label": "Login (app/routes/auth/login.tsx)"
    },
    {
      "type": "page",
      "path": "/striae-pages/primary-striae-interface-appstriaestriaetsx",
      "visibility": "PUBLIC",
      "label": "Primary Striae Interface (app/striae/striae.tsx)"
    }
  ],
  [
    {
      "type": "page",
      "path": "/untitled-section/canvas-component-canvastsx",
      "visibility": "PUBLIC",
      "label": "Canvas Component (canvas.tsx)"
    },
    {
      "type": "page",
      "path": "/untitled-section/sidebar-component-sidebartsx",
      "pages": [
        {
          "type": "page",
          "path": "/untitled-section/sidebar-component-sidebartsx/case-sidebar-component-case-sidebartsx",
          "fullSlug": "/untitled-section/sidebar-component-sidebartsx/case-sidebar-component-case-sidebartsx",
          "filePath": "/untitled-section/sidebar-component-sidebartsx/case-sidebar-component-case-sidebartsx",
          "label": "Case Sidebar Component (case-sidebar.tsx)",
          "slug": "case-sidebar-component-case-sidebartsx",
          "content": "## **Types**\n\n### `CaseSidebarProps`\n\nProps for the `CaseSidebar` component, including:\n\n* `user`: The current authenticated user.\n\n* `onImageSelect`: Callback for when an image is selected.\n\n* `onCaseChange`: Callback for when the case changes.\n\n* `imageLoaded`, `setImageLoaded`: Image loading state and setter.\n\n* `onNotesClick`: Callback to open the notes sidebar.\n\n* `files`, `setFiles`: List of files and setter.\n\n* `caseNumber`, `setCaseNumber`: Current input for case number and setter.\n\n* `currentCase`, `setCurrentCase`: The currently selected case and setter.\n\n* `error`, `setError`: Error message and setter.\n\n* `successAction`, `setSuccessAction`: Tracks the last successful action and setter.\n\n### `FileData`\n\nRepresents a file associated with a case:\n\n* `id`: File identifier.\n\n* `originalFilename`: Original file name.\n\n* `uploadedAt`: Upload timestamp.\n\n***\n\n## **Component**\n\n### `CaseSidebar(props: CaseSidebarProps)`\n\nA sidebar UI for case and file management.\n\n#### State:\n\n* `isDeletingCase`: Whether a case is being deleted.\n\n* `isRenaming`: Whether a case is being renamed.\n\n* `isLoading`: Whether a case or files are loading.\n\n* `isModalOpen`: Whether the case list modal is open.\n\n* `isUploadingFile`: Whether a file is being uploaded.\n\n* `uploadProgress`: Progress percentage for file upload.\n\n* `fileError`: Error message for file upload/delete.\n\n* `newCaseName`: Input for renaming a case.\n\n#### Effects:\n\n* Loads files for the selected case when `currentCase` changes.\n\n#### Main Features:\n\n* **Case Management:**\n\n  * Create or load a case by entering a case number.\n\n  * List all cases in a modal.\n\n  * Rename or delete the current case.\n\n* **File Management:**\n\n  * Upload image files (PNG, GIF, JPEG, WEBP, SVG, max 10MB).\n\n  * View, select, and delete files for the current case.\n\n  * Shows upload progress and error messages.\n\n* **Notes Access:**\n\n  * Button to open the notes sidebar for the selected image.\n\n* **Feedback:**\n\n  * Displays error and success messages for user actions.\n\n#### Accessibility:\n\n* File upload and delete actions are accessible via keyboard and screen readers.\n",
          "title": "Case Sidebar Component (case-sidebar.tsx)",
          "description": "This file defines a React component for managing cases and their associated files in the Striae application. It provides UI and logic for creating, selecting, renaming, and deleting cases, as well as uploading and deleting files.",
          "visibility": "PUBLIC",
          "format": "MDX",
          "pages": [],
          "numberOfMatterLines": 0
        },
        {
          "type": "page",
          "path": "/untitled-section/sidebar-component-sidebartsx/cases-modal-component-cases-modaltsx",
          "fullSlug": "/untitled-section/sidebar-component-sidebartsx/cases-modal-component-cases-modaltsx",
          "filePath": "/untitled-section/sidebar-component-sidebartsx/cases-modal-component-cases-modaltsx",
          "label": "Cases Modal Component (cases-modal.tsx)",
          "slug": "cases-modal-component-cases-modaltsx",
          "content": "## **Types**\n\n### `CasesModalProps`\n\nProps for the `CasesModal` component:\n\n* `isOpen: boolean` – Whether the modal is open.\n\n* `onClose: () => void` – Callback to close the modal.\n\n* `onSelectCase: (caseNum: string) => void` – Callback when a case is selected.\n\n* `currentCase: string` – The currently selected case.\n\n* `user: User` – The current authenticated user.\n\n***\n\n## **Component**\n\n### `CasesModal(props: CasesModalProps)`\n\nA modal dialog for viewing and selecting user cases.\n\n#### State:\n\n* `cases`: Array of case numbers for the user.\n\n* `isLoading`: Whether cases are being loaded.\n\n* `error`: Error message for loading failures.\n\n* `currentPage`: Current page number for pagination.\n\n#### Effects:\n\n* Adds an event listener to close the modal on `Escape` key press.\n\n* Loads the list of cases from the backend when the modal opens.\n\n#### Features:\n\n* **Case Listing:**\n\n  * Fetches and displays all cases for the user.\n\n  * Shows loading and error states.\n\n  * Displays a message if no cases are found.\n\n* **Pagination:**\n\n  * Shows up to 10 cases per page.\n\n  * Provides \"Previous\" and \"Next\" buttons for navigation if there are multiple pages.\n\n* **Case Selection:**\n\n  * Clicking a case selects it and closes the modal.\n\n  * Highlights the currently selected case.\n\n* **Accessibility:**\n\n  * Modal can be closed with the `Escape` key or the close button.\n",
          "title": "Cases Modal Component (cases-modal.tsx)",
          "description": "This file defines a React modal component for listing and selecting all cases associated with a user, with pagination and error handling.",
          "visibility": "PUBLIC",
          "format": "MDX",
          "pages": [],
          "numberOfMatterLines": 0
        },
        {
          "type": "page",
          "path": "/untitled-section/sidebar-component-sidebartsx/notes-sidebar-component-notes-sidebartsx",
          "fullSlug": "/untitled-section/sidebar-component-sidebartsx/notes-sidebar-component-notes-sidebartsx",
          "filePath": "/untitled-section/sidebar-component-sidebartsx/notes-sidebar-component-notes-sidebartsx",
          "label": "Notes Sidebar Component (notes-sidebar.tsx)",
          "slug": "notes-sidebar-component-notes-sidebartsx",
          "content": "## **Types**\n\n### `NotesSidebarProps`\n\nProps for the `NotesSidebar` component:\n\n* `currentCase: string` – The currently selected case number.\n\n* `onReturn: () => void` – Callback to return to case management.\n\n* `user: User` – The current authenticated user.\n\n* `imageId: string` – The ID of the selected image.\n\n### `NotesData`\n\nRepresents the structure of a notes object, including:\n\n* Case and item identifiers (`leftCase`, `rightCase`, `leftItem`, `rightItem`)\n\n* Font color, class type, custom class, class note, subclass flag\n\n* Index type, number, color\n\n* Support level, confirmation flag, additional notes\n\n* `updatedAt`: Timestamp of last update\n\n***\n\n## **Component**\n\n### `NotesSidebar(props: NotesSidebarProps)`\n\nA sidebar UI for editing and saving notes for a selected image.\n\n#### State:\n\n* Form fields for all note properties (case numbers, items, font color, class type, etc.)\n\n* `isLoading`: Whether notes are being loaded.\n\n* `loadError`: Error message for loading failures.\n\n* `saveSuccess`: Whether notes were saved successfully.\n\n* `isModalOpen`: Whether the additional notes modal is open.\n\n#### Effects:\n\n* Loads existing notes for the selected image and case on mount or when dependencies change.\n\n* Updates left/right case fields if \"use current case\" is toggled.\n\n#### Features:\n\n* **Case Information:**\n\n  * Inputs for left/right case and item numbers.\n\n  * Option to auto-fill with the current case number.\n\n  * Font color selection using `ColorSelector`.\n\n* **Class Characteristics:**\n\n  * Select class type (Bullet, Cartridge Case, Other).\n\n  * Input for custom class and class notes.\n\n  * Checkbox for subclass indication.\n\n* **Indexing:**\n\n  * Select index type (color or number).\n\n  * Input or color picker for index value.\n\n* **Support Level:**\n\n  * Select support level (ID, Exclusion, Inconclusive).\n\n  * Checkbox to include a confirmation field.\n\n* **Additional Notes:**\n\n  * Opens a modal for entering extra notes.\n\n* **Save/Return:**\n\n  * Button to save notes (calls backend).\n\n  * Button to return to case management.\n\n* **Feedback:**\n\n  * Displays loading, error, and success messages.\n",
          "title": "Notes Sidebar Component (notes-sidebar.tsx)",
          "description": "This file defines a React component for viewing and editing notes associated with a specific image in a user's case. It provides a detailed form for entering case, class, index, and support information, as well as additional notes.",
          "visibility": "PUBLIC",
          "format": "MDX",
          "pages": [],
          "numberOfMatterLines": 0
        },
        {
          "type": "page",
          "path": "/untitled-section/sidebar-component-sidebartsx/notes-modal-component-notes-modaltsx",
          "fullSlug": "/untitled-section/sidebar-component-sidebartsx/notes-modal-component-notes-modaltsx",
          "filePath": "/untitled-section/sidebar-component-sidebartsx/notes-modal-component-notes-modaltsx",
          "label": "Notes Modal Component (notes-modal.tsx)",
          "slug": "notes-modal-component-notes-modaltsx",
          "content": "## **Types**\n\n### `NotesModalProps`\n\nProps for the `NotesModal` component:\n\n* `isOpen: boolean` – Whether the modal is open.\n\n* `onClose: () => void` – Callback to close the modal.\n\n* `notes: string` – The current notes content.\n\n* `onSave: (notes: string) => void` – Callback to save the notes.\n\n***\n\n## **Component**\n\n### `NotesModal(props: NotesModalProps)`\n\nA modal dialog for editing additional notes.\n\n#### State:\n\n* `tempNotes`: Local state for the notes being edited.\n\n#### Effects:\n\n* Adds an event listener to close the modal on `Escape` key press when open.\n\n#### Features:\n\n* **Text Area:**\n\n  * Allows the user to edit the notes content.\n\n* **Save Button:**\n\n  * Saves the edited notes and closes the modal.\n\n* **Cancel Button:**\n\n  * Closes the modal without saving changes.\n\n* **Accessibility:**\n\n  * Modal can be closed with the `Escape` key or the cancel button.\n\n#### Rendering:\n\n* Returns `null` if the modal is not open.\n\n* Otherwise, displays the modal overlay and content.\n",
          "title": "Notes Modal Component (notes-modal.tsx)",
          "description": "This file defines a React modal component for editing and saving additional notes related to a case or image.",
          "visibility": "PUBLIC",
          "format": "MDX",
          "pages": [],
          "numberOfMatterLines": 0
        }
      ],
      "visibility": "PUBLIC",
      "label": "Sidebar Component (sidebar.tsx)"
    },
    {
      "type": "page",
      "path": "/untitled-section/color-selector-component-colorstsx",
      "visibility": "PUBLIC",
      "label": "Color Selector Component (colors.tsx)"
    },
    {
      "type": "page",
      "path": "/untitled-section/toolbar-component-toolbartsx",
      "visibility": "PUBLIC",
      "label": "Toolbar Component (toolbar.tsx)"
    },
    {
      "type": "page",
      "path": "/untitled-section/manageprofile-component-manage-profiletsx",
      "visibility": "PUBLIC",
      "label": "Manage Profile Component (manage-profile.tsx)"
    }
  ],
  [
    {
      "type": "page",
      "path": "/striae-components/additional-user-info-utility-additionaluserinfotsx",
      "visibility": "PUBLIC",
      "label": "Additional User Info Utility (additionalUserInfo.tsx)"
    },
    {
      "type": "page",
      "path": "/striae-components/case-management-utilities-case-managetsx",
      "visibility": "PUBLIC",
      "label": "Case Management Utilities (case-manage.tsx)"
    },
    {
      "type": "page",
      "path": "/striae-components/image-management-utilities-image-managetsx",
      "visibility": "PUBLIC",
      "label": "Image Management Utilities (image-manage.tsx)"
    },
    {
      "type": "page",
      "path": "/striae-components/notes-management-utilities-notes-managetsx",
      "visibility": "PUBLIC",
      "label": "Notes Management Utilities (notes-manage.tsx)"
    }
  ],
  [
    {
      "type": "page",
      "path": "/allyforensics-workers/image-worker-awefoijawoefi3497823",
      "visibility": "PUBLIC",
      "label": "Image Worker"
    },
    {
      "type": "page",
      "path": "/allyforensics-workers/data-workeroioigjnvukhvf972973492038",
      "visibility": "PUBLIC",
      "label": "Data Worker"
    },
    {
      "type": "page",
      "path": "/allyforensics-workers/auth-utility-functions-authts",
      "visibility": "PUBLIC",
      "label": "Auth Utility Functions (auth.ts)"
    },
    {
      "type": "page",
      "path": "/allyforensics-workers/keys-worker-keysjs-function-documentation",
      "visibility": "PUBLIC",
      "label": "Keys Worker (keys.js) – Function Documentation"
    },
    {
      "type": "page",
      "path": "/allyforensics-workers/user-worker-user-workerjs-function-documentation",
      "visibility": "PUBLIC",
      "label": "User Worker (user-worker.js) – Function Documentation"
    }
  ],
  [
    {
      "type": "page",
      "path": "/projects/how-to-implement-cloudflares-turnstile",
      "visibility": "PUBLIC",
      "label": "Cloudflare Turnstile with React"
    },
    {
      "type": "page",
      "path": "/projects/using-cloudflare-r2-object-storage-to-serve-a-comments-field",
      "visibility": "PUBLIC",
      "label": "Comments Field with Cloudflare R2 Object Storage"
    }
  ]
],
};