---
title: Sidebar Component (sidebar.tsx)
label: Sidebar Component (sidebar.tsx)
slug: sidebar-component-sidebartsx
description: >-
  This file defines the main sidebar component for the Striae application,
  providing user info, profile management, case navigation, and notes access.
visibility: PUBLIC
---
## **Types**

### `FileData`

Represents a file associated with a case:

* `id`: File identifier.

* `originalFilename`: Original file name.

* `uploadedAt`: Upload timestamp.

### `SidebarProps`

Props for the `Sidebar` component, including:

* `user`: The current authenticated user.

* `onImageSelect`: Callback for when an image is selected.

* `imageId`: The currently selected image ID.

* `onCaseChange`, `currentCase`, `setCurrentCase`: Case selection and management.

* `files`, `setFiles`: List of files and setter.

* `imageLoaded`, `setImageLoaded`: Image loading state and setter.

* `caseNumber`, `setCaseNumber`: Current case number and setter.

* `error`, `setError`: Error message and setter.

* `successAction`, `setSuccessAction`: Tracks the last successful action and setter.

* `showNotes`, `setShowNotes`: Whether the notes sidebar is shown and setter.

***

## **Component**

### `Sidebar(props: SidebarProps)`

A sidebar UI for user and case management.

#### State:

* `isProfileModalOpen`: Controls the visibility of the profile management modal.

#### UI Features:

* **User Info Section:**

  * Displays the user's first name and "Striae".

  * Buttons for managing the profile and signing out.

* **Profile Modal:**

  * Renders the `ManageProfile` modal when open.

* **Sidebar Content:**

  * If `showNotes` is true, displays the `NotesSidebar` for the current case and image.

  * Otherwise, displays the `CaseSidebar` for case and file management, passing all relevant props and a callback to open the notes sidebar.
