---
title: Auth Utility Functions (auth.ts)
label: Auth Utility Functions (auth.ts)
slug: auth-utility-functions-authts
description: >-
  This file provides utility functions for securely retrieving various API keys
  and account information from a remote key management service, using
  credentials from the app's configuration.
visibility: PUBLIC
---
## **Constants**

* **KEYS\_URL**: The base URL for the key management service, loaded from `config.json`.

* **KEYS\_AUTH**: The authentication key for accessing the key management service, loaded from `config.json`.

## **Functions**

### `getUserApiKey(): Promise<string>`

Fetches the API key for user database operations.

* Makes a GET request to `${KEYS_URL}/USER_DB_AUTH` with the custom auth header.

* Throws an error if the request fails.

* Returns the API key as a string.

### `getDataApiKey(): Promise<string>`

Fetches the API key for data storage (R2) operations.

* Makes a GET request to `${KEYS_URL}/R2_KEY_SECRET` with the custom auth header.

* Throws an error if the request fails.

* Returns the API key as a string.

### `getImageApiKey(): Promise<string>`

Fetches the API key for image API operations.

* Makes a GET request to `${KEYS_URL}/IMAGES_API_TOKEN` with the custom auth header.

* Throws an error if the request fails.

* Returns the API key as a string.

### `getAccountHash(): Promise<string>`

Fetches the account hash for the current user/account.

* Makes a GET request to `${KEYS_URL}/ACCOUNT_HASH` with the custom auth header.

* Throws an error if the request fails.

* Returns the account hash as a string.

***

All functions use the same pattern: fetch the secret from a remote endpoint with authentication, check for errors, and return the result as plain text. These are used throughout the app to securely access backend services.
