---
title: Using Cloudflare R2 Object Storage to Serve a Comments Field
label: Comments Field with Cloudflare R2 Object Storage
slug: using-cloudflare-r2-object-storage-to-serve-a-comments-field
visibility: PUBLIC
---
<Image src="https://cdn.hashnode.com/res/hashnode/image/upload/v1736036693085/c7fd102c-79e4-44fc-9e48-e4e87195889e.png" alt="" align="center" fullwidth="true" />

This application demonstrates integration of Cloudflare’s R2 Object Storage to serve a comments field.

* <a target="_blank" href="https://github.com/StephenJLu/comments-r2">**GitHub Repo**</a>

* Check out the <a target="_blank" href="https://comments.stephenjlu.com/">**live demo**</a>

* <a target="_blank" href="https://ledger.stephenjlu.com/how-i-made-a-comments-field-with-cloudflare-r2-object-storage">**My blog post about this**</a>

# Getting Started

## **Prerequisites**

* Node.js 20.0.0 or higher

* npm

* Cloudflare account

## **Comments Test Installation**

1. Clone the repository

2. Install dependencies:

```plaintext
npm install
```

## Create an R2 Bucket, Set CORS Policy, Initialize Empty JSON

1. Create a Standard Class R2 Bucket in Cloudflare

2. Add a custom domain for public access (if desired). Skip this to restrict public access to data.

3. Edit the CORS policy:

   ```json
   [
     {
       "AllowedOrigins": [
         "*"
       ],
       "AllowedMethods": [
         "GET",
         "PUT",
         "POST",
         "DELETE"
       ],
       "AllowedHeaders": [
         "*"
       ],
       "ExposeHeaders": [
         "Content-Type",
         "Content-Length"
       ],
       "MaxAgeSeconds": 3600
     }
   ]
   ```

   4. Upload an empty JSON file (`comments.json`) to the bucket to initialize the comments array

      ```json
      # comments.json

      []
      ```

## **Cloudflare Worker: Set Variables, Bindings, and Deploy**

1. For local development, insert your R2 authentication key into `.dev.vars.example`

2. Rename it to `.dev.vars` (check `.gitignore` for `.dev.vars`)

   ```plaintext
   # Rename this file from .dev.vars.example to .dev.vars and 
   # paste in your credentials

   AUTH_KEY_SECRET=ENTER_R2_AUTH_KEY
   ```

3. In `r2-worker.js`, replace `R2_BUCKET` with your specific bucket variable:

   ```javascript
   /* ... worker.js code 
   */
   if (!hasValidHeader(request, env)) {
           return createResponse({ error: 'Forbidden' }, 403);
         }
     
         try {
           const bucket = env.INSERT_YOUR_BUCKET_VARIABLE;
           
           switch (request.method) {

   /* ... rest of worker.js */
   ```

4. Deploy `r2-worker.js` on Cloudflare under your account.

5. For live production, set your R2 authentication key as an environment variable or secret as `AUTH_KEY_SECRET` for the Worker.

6. Bind your Worker to the R2 Bucket.

In the end, your settings should look something like this:

### **Worker Settings:**

<Image src="https://cdn.hashnode.com/res/hashnode/image/upload/v1736039009943/3f010f4b-64d4-4ad1-ae68-a75d0994e81c.png" alt="" align="center" fullwidth="true" />

### **R2 Binding:**

<Image src="https://cdn.hashnode.com/res/hashnode/image/upload/v1736039027785/4f3e2861-1b11-47ad-8cb6-dd5246cb25f3.png" alt="" align="center" fullwidth="true" />

## Set Your Page Environment Variables

1. In your Cloudflare Pages settings, set an environment variable or secret, `AUTH_KEY_SECRET` to your R2 authentication key.

OR

1. Edit `wrangler.toml` to include your authentication key:

   ```plaintext
   #:schema node_modules/wrangler/config-schema.json

   name = "comments-r2" // CHANGE TO YOUR PAGES PROJECT NAME

   compatibility_date = "2024-12-30"
   pages_build_output_dir = "./build/client"

   ######## PRODUCTION environment config ########

   # [env.production.vars]
   # AUTH_KEY_SECRET = "ENTER_AUTH_KEY_HERE"
   ```

## Set Worker and R2 URLs in paths.json

1. Insert the paths to your `comments.json` file through the Worker:

   ```json
   {
     "worker_url": "INSERT_WORKER_URL/comments.json"
   }
   ```

## Development

Run the dev server:

```javascript
npm run dev
```

To run Wrangler:

```javascript
npm run build
npm run start
```

## Typegen

Generate types for your Cloudflare bindings in `wrangler.toml`:

```javascript
npm run typegen
```

You will need to rerun `typegen` whenever you make changes to `wrangler.toml`.

## Deployment

First, build your app for production:

```plaintext
npm run build
```

Then, deploy your app to Cloudflare Pages:

```plaintext
npm run deploy
```

## Styling

This template comes with [Tailwind CSS](https://tailwindcss.com/) already configured for a simple default starting experience. You can use whatever css framework you prefer. See the [Vite docs on css](https://vitejs.dev/guide/features.html#css) for more information.

# Comments Implementation

After following the initial setup as described above, you can include any type of fields you want, protect comments behind a login, and/or CAPTCHA.

* To see an implementation of the comments with <a target="_blank" href="https://developers.cloudflare.com/turnstile/">Cloudflare Turnstile</a> protection applied, go here: [https://www.stephenjlu.com/r2-test](https://www.stephenjlu.com/r2-test).

* The source code for the above implementation is here: [https://github.com/StephenJLu/stephenjlu/tree/main/app/routes/r2-test](https://github.com/StephenJLu/stephenjlu/tree/main/app/routes/r2-test)

* To see an implementation of **Cloudflare’s Turnstile** in isolation:

  * <a target="_blank" href="https://www.stephenjlu.com/test">Live Demo</a>

  * <a target="_blank" href="https://docs.stephenjlu.com/docs-stephenjlu/projects/how-to-implement-cloudflares-turnstile">Documentation</a>

  * <a target="_blank" href="https://github.com/StephenJLu/cloudflare-turnstile-react">GitHub Repo</a>

## Questions/Issues

I welcome pull requests and issues. You can also <a target="_blank" href="https://stephenjlu.com/contact">contact me</a> directly.
