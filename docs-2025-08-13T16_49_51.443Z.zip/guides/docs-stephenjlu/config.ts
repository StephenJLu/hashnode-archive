export default {
    variant: "GUIDE",
    settings: {
        name: "Docs@StephenJLu.com",
        slug: "docs-stephenjlu",
    },
};